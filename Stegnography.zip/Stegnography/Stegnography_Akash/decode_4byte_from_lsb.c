#include "decode.h"

int decode_4byte_from_lsb(char* buffer_32){
    
    int size=0;
    for(int i=31;i>=0;i--){
        size|=((buffer_32[31-i]&1)<<i);
    }


    return size;
}