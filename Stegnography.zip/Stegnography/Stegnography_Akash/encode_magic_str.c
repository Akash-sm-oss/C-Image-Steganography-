#include "encode.h"

Status encode_magic_string(const char * magic_string,EncodeInfo *encInfo){
    char img_bytes[8];

    //run the loop from 0 to length of magic_string
    for(int i=0;i<strlen(magic_string);i++){
        //read 8 bytes from the src
        if(fread(img_bytes,sizeof(img_bytes),1,encInfo->src_image_fptr)==0){
            return failure;
        };

        // then do encode_1byte from lsb
        encode_1byte_to_lsb(magic_string[i],img_bytes);

        //write 8 bytes  into stego.bmp or output file
        if(fwrite(img_bytes,sizeof(img_bytes),1,encInfo->output_image_fptr)==0){
            return failure;
        };
    }

    return success;
}

