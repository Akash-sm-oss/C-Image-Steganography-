#include<iostream>
using namespace std;

int main(){
    cout<<"I am doing encoding and decoding process"<<endl;
    return 0;
}