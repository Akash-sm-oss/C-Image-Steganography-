#include "encode.h"

Status copy_bmp_header(EncodeInfo *encInfo){

    //get 54 bytes from header of src then store it into buffer 
    //and then write into a output file as out.bmp
    char buffer[54];

    // encInfo->src_image_fptr=fopen(encInfo->src_image_fname,"r");

    // if (encInfo->src_image_fptr == NULL){
    // 	perror("fopen");
    // 	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    // 	return failure;
    // }

    rewind(encInfo->src_image_fptr);

    if(fread(buffer,sizeof(buffer),1,encInfo->src_image_fptr)==0){
        return failure;
    };

    //fclose(encInfo->src_image_fptr);

    //open the output the store buffer character bytes into the out.bmp file

    // encInfo->output_image_fptr=fopen(encInfo->output_image_fptr,"w");

    //  if (encInfo->output_image_fptr == NULL){
    // 	perror("fopen");
    // 	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->output_image_fname);

    // 	return failure;
    // }

    if(fwrite(buffer,sizeof(buffer),1,encInfo->output_image_fptr)==0){
        return failure;
    };

    //fclose(encInfo->output_image_fptr);

    return success;
}