#include "encode.h"

Status copy_remaining_img_data(EncodeInfo * encInfo){
    //read the remaining bytes from src file
    //then write into the output file

    char ch;
    while(fread(&ch,sizeof(ch),1,encInfo->src_image_fptr)!=0){
        //printf("%ld\n", ftell(encInfo->src_image_fptr));
        fwrite(&ch,sizeof(ch),1,encInfo->output_image_fptr);
    }
    return success;
}