#include "decode.h"

Status decode_secret_file_extn(DecodeInfo *decInfo){

    //extract extension size
    //read the 32 bytes from src encoded file .bmp file
    char file_extn[32];
    
    if(fread(file_extn,sizeof(file_extn),1,decInfo->stego_img_fptr)==0){
        return failure;
    };

    int extn_size=decode_4byte_from_lsb(file_extn);

    //extract extension from img file
    char secret_extn[extn_size];
    char secret_file[8];

    for(int i=0;i<extn_size;i++){

        if(fread(secret_file,sizeof(secret_file),1,decInfo->stego_img_fptr)==0){
            return failure;
        };

        secret_extn[i]=decode_1byte_from_lsb(secret_file);
    }

    secret_extn[extn_size]='\0';

    //merging secret_file with extension
    decInfo->output_secret_fname=strcat(decInfo->output_secret_fname,secret_extn);

    //open the secret file in the write mode
    decInfo->output_secret_fptr=fopen(decInfo->output_secret_fname,"w");

    return success;


}