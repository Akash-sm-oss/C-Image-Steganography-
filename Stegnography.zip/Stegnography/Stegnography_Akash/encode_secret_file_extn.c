#include "encode.h"

Status encode_secret_file_extn(EncodeInfo *encInfo){
    //encode the extension size
    //extract 32 bytes from the src file

    char secret_file[32];
    if(fread(secret_file,sizeof(secret_file),1,encInfo->src_image_fptr)==0){
        return failure;
    };

    //then call the encode 4bytes from lsb
    encode_4byte_to_lsb(encInfo->secret_extn_size,secret_file);

    //the write into output file that is out.bmp or stego.bmp
    if(fwrite(secret_file,sizeof(secret_file),1,encInfo->output_image_fptr)==0){
        return failure;
    };


    //encode the extension length
    char secret_len[8];

    for(int i=0;i<strlen(encInfo->secret_extn);i++){

        //read the 8bytes from src file is beautiful.bmp
        if(fread(secret_len,sizeof(secret_len),1,encInfo->src_image_fptr)==0){
            return failure;
        };

        //encode each byte call the encode_1byte_to_lsb
        encode_1byte_to_lsb(encInfo->secret_extn[i],secret_len);

        //write into the output file
        if(fwrite(secret_len,sizeof(secret_len),1,encInfo->output_image_fptr)==0){
            return failure;
        };
        
    }

    return success;
}

