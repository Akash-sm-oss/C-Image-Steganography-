#include "encode.h"


Status encode_4byte_to_lsb(int data,char* buffer_32){
    int get_msb;
    for(int i=31;i>=0;i--){
        get_msb=(data>>i)&1;
        buffer_32[31-i]=buffer_32[31-i] &(~1);
        buffer_32[31-i]|=get_msb;

    }

    return success;
}