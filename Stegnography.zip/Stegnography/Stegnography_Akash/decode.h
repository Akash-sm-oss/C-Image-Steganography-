#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include "common.h"

#ifndef DECODE_H
#define DECODE_H

typedef struct DecodeInfo{
    char* stego_name;
    FILE* stego_img_fptr;

    char* output_secret_fname;
    FILE* output_secret_fptr;

} DecodeInfo;

/*Read and validate Decode args from argv*/
Status validate_decode_args(char* argv[],DecodeInfo *decInfo);

/* Perform the decoding */
Status do_decoding(char* argv[],DecodeInfo *decInfo);

/*Opening image file*/
Status open_img_file(DecodeInfo *decInfo);

/*decode the magic string*/
Status decode_magic_string(const char *magic_string,DecodeInfo *decInfo);

/*Decode secret file extension*/
Status decode_secret_file_extn(DecodeInfo *decInfo);

/*decode secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo);

char decode_1byte_from_lsb(char* buffer_8);

int decode_4byte_from_lsb(char* buffer_32);

#endif