#include "common.h"
#include "encode.h"

Status encode_1byte_to_lsb(char data,char *buffer_8){

    int get_msb;
    for(int i=7;i>=0;i--){
        get_msb=(data>>i)&1;//get the msb bit of data
        buffer_8[7-i]=buffer_8[7-i] & (~1);//clear the lsb bit of image bytes
        buffer_8[7-i]|=get_msb; //encoded image byte is this
    }

    return success;

}