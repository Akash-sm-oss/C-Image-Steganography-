#include "encode.h"
#include "common.h"

Status do_encoding(char *argv[], EncodeInfo *encInfo){
    //validate the encode arguments
    if(validate_encode_args(argv,encInfo)==failure){
        return failure;
    }
    else{
        printf("\nValidation of encode arguments done successfully.\n");
    }

    //open the all files
    if(open_files(encInfo)==failure){
        return failure;
    }
    else{
        printf("Files were opened successfully.\n");
    }

    //comparison src file with encode things 
    if(check_capacity(encInfo)==failure){
        return failure;
    }
    else{
        printf("Capacity checking done successfully.\n");
    }

    //copied header bytes of src bmp file
    if(copy_bmp_header(encInfo)==failure){
        return failure;
    }
    else{
        printf("Copied header bytes from src to dest done successfully.\n");
    }

    if(encode_magic_string(MAGIC_STRING,encInfo)==failure){
        return failure;
    }
    else{
        printf("Magic string encoding done successfully.\n");
    }

    if(encode_secret_file_extn(encInfo)==failure){
        return failure;
    }
    else{
        printf("Secret file extension encoding done successfully.\n");
    }

    if(encode_secret_file_data(encInfo)==failure){
        return failure;
    }
    else{
        printf("Secret file data encoding done successfully.\n");
    }

    if(copy_remaining_img_data(encInfo)==failure){
        return failure;
    }
    else{
        printf("Remaining img data copied to output file successfully.\n");
    }

    return success;

}

Status validate_encode_args(char* argv[],EncodeInfo *encInfo){
    //check that argv[2] has .bmp extension or not
    int len=strlen(argv[2]);
    char* bmp_file=argv[2];

    if(len>4 && strcmp(bmp_file+len-4,".bmp")==0){
        //then store the filename into the struct member is src_image_fname
        encInfo->src_image_fname=bmp_file;
    }
    else{
        printf("Please enter a valid fileName with extension of bmp.\n");
        return failure;
    }


    //check that argv[3] has .c/.cpp/.sh/.txt/.py extension or not


    len=strlen(argv[3]);
    char* secret_file=argv[3];

    if( (len>4 && strcmp(secret_file+len-4,".txt")==0) || 
        (len>2 && strcmp(secret_file+len-2,".c")==0) ||
        (len>4 && strcmp(secret_file+len-4,".cpp")==0) ||
        (len>3 && strcmp(secret_file+len-3,".sh")==0) ||
        (len>3 && strcmp(secret_file+len-3,".py")==0)
    ){
        //if any one of the extension matched 
        //then store fileName into secret_fname
        encInfo->secret_fname=secret_file;

        //extract the extension and store it into secret_extn string
        //find the . character address using strrchr
        char * ext=strrchr(secret_file,'.');

        strcpy(encInfo->secret_extn,ext);

        encInfo->secret_extn_size=strlen(encInfo->secret_extn);

    }
    else{
        printf("Please enter a valid fileName with valid extension.\n");
        return failure;
    }

    //check the argv[4] is null or not

    if(argv[4]==NULL){
        //take default name store it into the struct output_image_fname

        char* default_Name="stego.bmp";
        encInfo->output_image_fname=default_Name;
    }
    else{
        //if not null or present
        //check argv[4] is .bmp extension or not
        int len=strlen(argv[4]);
        char* output_file=argv[4];

        if(len>4 && strcmp(output_file+len-4,".bmp")==0){
            //then store the filename into the struct member is output_image_fname
            encInfo->output_image_fname=output_file;
        }
        else{
            printf("Please enter a valid output fileName with bmp extension.\n");
            return failure;
        }
    }

    return success;
}


Status check_capacity(EncodeInfo *encInfo){
    //get the image size
    unsigned int img_capacity=get_image_size_for_bmp(encInfo->src_image_fptr);

    //calculate length of MAGIC_STRING 
    //length of secret_extn
    //length of secret file size

    unsigned int secret_file_size=get_file_size(encInfo->secret_fptr,encInfo->secret_fname);

    encInfo->secret_file_size=secret_file_size;

    unsigned int encode_things=(strlen(MAGIC_STRING)+sizeof(int)+strlen(encInfo->secret_extn)+sizeof(int)+secret_file_size)*8;

    //compare img_capacity with encoding things
    if(img_capacity>encode_things){
        return success;
    }
    else{
        return failure;
    }

    return success;
}


unsigned int get_file_size(FILE* fptr,char* secret_file){
    fptr=fopen(secret_file,"r");

    if(fptr==NULL){
        perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n",secret_file);
        return 0;
    }

    fseek(fptr,0,SEEK_END);
    int size=ftell(fptr);

    fclose(fptr);

    return size;
}