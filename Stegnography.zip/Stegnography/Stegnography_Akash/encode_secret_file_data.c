#include "encode.h"

Status encode_secret_file_data(EncodeInfo* encInfo){
    //encode the secret_file size

    char secret_file_data[32];
    //read 32 bytes from src file that is beautiful.bmp

    if(fread(secret_file_data,sizeof(secret_file_data),1,encInfo->src_image_fptr)==0){
        return failure;
    };


    encode_4byte_to_lsb(encInfo->secret_file_size,secret_file_data);

    //write into output file that is stego.bmp

    if(fwrite(secret_file_data,sizeof(secret_file_data),1,encInfo->output_image_fptr)==0){
        return failure;
    };

    
    //encode secret message from secret file
    char ch;
    char secret_msg[8];

    while(fread(&ch,sizeof(ch),1,encInfo->secret_fptr)==1){
        //read the 8 bytes from the img
        if(fread(secret_msg,sizeof(secret_msg),1,encInfo->src_image_fptr)==0){
            return failure;
        };

        //encode each byte
        encode_1byte_to_lsb(ch,secret_msg);

        //write into the output file
        if(fwrite(secret_msg,sizeof(secret_msg),1,encInfo->output_image_fptr)==0){
            return failure;
        };
    }

    return success;

}