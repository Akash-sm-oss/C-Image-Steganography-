#include "decode.h"

char decode_1byte_from_lsb(char* buffer_8){
    
    char ch=0;
    for(int i=7;i>=0;i--){
        ch|=((buffer_8[7-i]&1)<<i);
    }


    return ch;
}