#include "decode.h"

Status decode_secret_file_data(DecodeInfo *decInfo){

    //extact the size of secret file data
    char file_size[32];

    //read 32 bytes from the src img file 
    if(fread(file_size,sizeof(file_size),1,decInfo->stego_img_fptr)==0){
        return failure;
    }

    int f_size=decode_4byte_from_lsb(file_size);


    char file_data[8];
    char secret_msg[f_size];

    for(int i=0;i<f_size;i++){
        //read 8 bytes from user
        fread(file_data,sizeof(file_data),1,decInfo->stego_img_fptr);
        secret_msg[i]=decode_1byte_from_lsb(file_data);
    }

    fwrite(secret_msg,sizeof(secret_msg),1,decInfo->output_secret_fptr);
    
    return success;
  
}