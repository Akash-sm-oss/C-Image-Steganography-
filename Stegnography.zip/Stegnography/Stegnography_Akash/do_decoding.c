#include "decode.h"

Status do_decoding(char* argv[],DecodeInfo* decInfo){
    if(validate_decode_args(argv,decInfo)==failure){
        return failure;
    }
    else{
        printf("\nDecode arguments validation done successfully.\n");
    }

    if(open_img_file(decInfo)==failure){
        return failure;
    }
    else{
        printf("Img file is opened successfully.\n");
    }

    if(decode_magic_string(MAGIC_STRING,decInfo)==failure){
        return failure;
    }
    else{
        printf("Magic string decoded successfully.\n");
    }

    if(decode_secret_file_extn(decInfo)==failure){
        return failure;
    }
    else{
        printf("Decoding the secret file done successfully.\n");
    }

    if(decode_secret_file_data(decInfo)==failure){
        return failure;
    }
    else{
        printf("Decoding the secret file data done successfully.\n");
    }


    return success;
}

Status validate_decode_args(char* argv[],DecodeInfo* decInfo){
    //argv[2] have .bmp extension or not
    int len=strlen(argv[2]);
    char* bmf_file=argv[2];

    if(len>4 && strcmp(bmf_file+len-4,".bmp")==0){
        decInfo->stego_name=bmf_file;
    }
    else{
        printf("Enter valid file name with extension is .bmp\n");
        return failure;
    }


    //check that argv[3] is null or not
    if(argv[3]==NULL){
        //store default filename into output secret name
        decInfo->output_secret_fname="Secret";
    }
    else{
        //check that extension is present or not
        char* out_file=argv[3];
        char* extn=strrchr(argv[3],'.');

        if(extn!=NULL){

            out_file[strlen(out_file)-strlen(extn)]='\0';
            decInfo->output_secret_fname=out_file;
        }
        else{
            decInfo->output_secret_fname=argv[3];
        }
    }

    return success;

}