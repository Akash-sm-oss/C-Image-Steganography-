#include "encode.h"
#include "decode.h"

int main(int argc, char *argv[])
{
    EncodeInfo encodeInfo;
    DecodeInfo decodeInfo;

    if( argc == 1 ){
        // print -> Error + usage msg
        printf("One argument is not enough.\n");
        return 0;
    }

    int opr = check_operation(argv[1]);

    if( opr == encode ){
        if( argc < 4 || argc > 5 )
        {
            // print -> Error + usage msg
            printf("Arguments count should be within the 4 and 5.\n");
            return 0;
        }
        else{
            printf("\n---------------------------Encoding Process Started --------------------------\n");
            do_encoding(argv,&encodeInfo);
            printf("\n---------------------------Encoding Process Ended ----------------------------\n");
        }
    }
    else if( opr == decode )
    {
	if( argc < 3 || argc > 4 )	
	{
	    printf("Arguments count should be within the 4 and 5.\n");
	    return 0;
	}
    else{
        printf("\n---------------------------Decoding Process Started --------------------------\n");
        do_decoding(argv,&decodeInfo);
        printf("\n---------------------------Decoding Process Ended ----------------------------\n");
    }
    }
    else{
        // Print -> Error + usage msg
        printf("Enter a valid operation option.\n");
    }
    return 0;
}
