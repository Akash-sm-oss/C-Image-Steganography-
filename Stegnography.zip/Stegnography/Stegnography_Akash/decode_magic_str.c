#include "decode.h"

Status decode_magic_string(const char* magic_string,DecodeInfo *decInfo){
    //skip the bmp header
    rewind(decInfo->stego_img_fptr);
    fseek(decInfo->stego_img_fptr,54,SEEK_SET);

    //storing the magic string in char magic 
    char magic[strlen(magic_string)+1];

    char img_buffer[8];

    for(int i=0;i<strlen(magic_string);i++){
        //read the 8bytes from src img encode file
        fread(img_buffer,sizeof(img_buffer),1,decInfo->stego_img_fptr);

        magic[i]=decode_1byte_from_lsb(img_buffer);
    }

    magic[strlen(magic_string)]='\0';

    //compare extracted magic string with original magic string
    if(strcmp(magic,magic_string)==0){
        return success;
    }
    else{
        return failure;
    }

    return success;

}