#include "encode.h"
#include "common.h"


Opr_type check_operation(char *option){
    if(strcmp(option,"-e")==0){
        return encode;
    }

    if(strcmp(option,"-d")==0){
        return decode;
    }
    return unsupported;
}
