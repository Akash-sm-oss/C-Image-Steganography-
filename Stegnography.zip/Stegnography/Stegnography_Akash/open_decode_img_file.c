#include "decode.h"

Status open_img_file(DecodeInfo *decInfo){
    decInfo->stego_img_fptr=fopen(decInfo->stego_name,"r");

    if(decInfo->stego_img_fptr==NULL){
        perror("fopen");
        fprintf(stderr,"ERROR: Unable to open file %s\n",decInfo->stego_name);

        return failure;
    }

    return success;
}